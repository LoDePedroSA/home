@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title Descargador de Archivos

cd /d "%~dp0"

set "logfile=logs.txt"
set "urls_count=0"
set "error_occurred=0"

if not exist "!logfile!" (
    (
        echo language: Español Latinoamerica - ES-LM
    ) > "!logfile!"
) else (
    echo. >> "!logfile!"
)

echo. >> "!logfile!"
echo ------------------------------------------- >> "!logfile!"

cls
echo ========================================
echo      DESCARGADOR DE ARCHIVOS
echo ========================================
echo.
echo Ingrese una o mas URLs (deje en blanco para finalizar)
echo.

:urls_input
set "url="
set /p "url=URL #!urls_count! (Enter para finalizar): "

if not defined url (
    if !urls_count! equ 0 (
        echo.
        echo Debe ingresar al menos una URL.
        echo.
        goto urls_input
    )
    goto urls_done
)

set "url_!urls_count!=!url!"
set /a urls_count+=1
goto urls_input

:urls_done
echo.
echo Seleccione la ubicacion de descarga:
echo    [1] Escritorio
echo    [2] Descargas
echo    [3] Documentos
echo    [4] Ubicacion personalizada
echo.

set /p "opcion=Opcion (1, 2, 3 o 4): "

if "!opcion!"=="1" (
    set "destino=!USERPROFILE!\Desktop"
) else if "!opcion!"=="2" (
    set "destino=!USERPROFILE!\Downloads"
) else if "!opcion!"=="3" (
    set "destino=!USERPROFILE!\Documents"
) else if "!opcion!"=="4" (
    set /p "destino=Ingrese la ruta de descarga: "
    if not exist "!destino!" (
        mkdir "!destino!"
    )
) else (
    echo Opcion no valida. Usando Escritorio por defecto.
    set "destino=!USERPROFILE!\Desktop"
)

set "tool="
if exist "wget.exe" (
    set "tool=wget"
) else if exist "aria2c.exe" (
    set "tool=aria2c"
) else (
    echo.
    echo ERROR: No se encontro wget.exe ni aria2c.exe en el sistema.
    echo.
    for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c/%%a/%%b)
    for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set mytime=%%a:%%b)
    echo !mydate! - !mytime! - Error: Herramientas de descarga no encontradas >> "!logfile!"
    echo Presione cualquier tecla para salir...
    pause >nul
    exit /b 1
)

cls
echo ========================================
echo      DESCARGADOR DE ARCHIVOS
echo ========================================
echo.
echo Herramienta detectada: !tool!
echo Destino: !destino!
echo Archivos a descargar: !urls_count!
echo.
echo Iniciando descarga...
echo.

for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c/%%a/%%b)
for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set mytime=%%a:%%b)
echo !mydate! - !mytime! - Inicio de descarga de archivo/s: >> "!logfile!"

for /l %%i in (0,1,!urls_count-1!) do (
    set "current_url=!url_%%i!"
    echo   [%%i] !current_url! >> "!logfile!"
    echo [!url_%%i!]
)

echo.

for /l %%i in (0,1,!urls_count-1!) do (
    set "current_url=!url_%%i!"
    
    if "!tool!"=="wget" (
        echo Descargando: !current_url!
        
        if "!current_url:~-1!"=="/" (
            wget.exe -r -p -nH -P "!destino!" "!current_url!" 2>nul
        ) else (
            wget.exe -p -nH -P "!destino!" "!current_url!" 2>nul
        )
    ) else if "!tool!"=="aria2c" (
        echo Descargando: !current_url!
        aria2c.exe -x 16 -s 16 -d "!destino!" "!current_url!" 2>nul
    )
    
    if !errorlevel! neq 0 (
        set "error_occurred=1"
        echo Error en: !current_url!
        for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c/%%a/%%b)
        for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set mytime=%%a:%%b)
        echo !mydate! - !mytime! - Error: Fallo descargando !current_url! >> "!logfile!"
    ) else (
        echo Completado: !current_url!
    )
    
    echo.
)

for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c/%%a/%%b)
for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set mytime=%%a:%%b)
echo !mydate! - !mytime! - Fin de la descarga de archivo/s >> "!logfile!"

echo.
if !error_occurred! equ 1 (
    echo Descarga completada con errores.
) else (
    echo Descarga finalizada exitosamente.
)
echo.
echo Presione cualquier tecla para salir...
pause >nul
endlocal